package com.zybooks.kidstylenoldosage

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private lateinit var weightEditText: EditText
    private lateinit var weightUnitRadioGroup: RadioGroup
    private lateinit var frequencyRadioGroup: RadioGroup
    private lateinit var dosageTextView: TextView
    private var weightInKgs: Double = 0.0
    private var dosage: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        weightEditText = findViewById(R.id.editTextNumberDecimal)
        weightUnitRadioGroup = findViewById(R.id.weight_unit_radio_group)
        frequencyRadioGroup = findViewById(R.id.frequency_radio_group)
        dosageTextView = findViewById(R.id.dosage_text_view)

        if (savedInstanceState != null) {
            dosage = savedInstanceState.getString("dosage", "")
            dosageTextView.text = dosage
            weightInKgs = savedInstanceState.getDouble("weightInKgs", 0.0)
        }
    }

    fun calculateClick(view: View) {
        val weightStr = weightEditText.text.toString()

        var weight = weightStr.toDoubleOrNull() ?: 0.0

        if (weightUnitRadioGroup.checkedRadioButtonId == R.id.lbs_radio_button) {
            weight /= 2.2
        }
        weightInKgs = weight

        val frequency = if (frequencyRadioGroup.checkedRadioButtonId == R.id.four_radio_button) 4 else 6

        val calculatedDosage = calculateDosage(weight, frequency)

        dosage = "Dosage: $calculatedDosage"
    }
    private fun calculateDosage(weight: Double, frequency: Int): Double {
        val dosagePerMl = 160.0 / 5.0

        val dosage: Double = when (frequency) {
            4 -> {
                val dosageNeeded = 10.0 * weight
                val mLNeeded = (dosageNeeded * 5) / dosagePerMl
                mLNeeded
            }
            6 -> {
                val dosageNeeded = 15.0 * weight
                val mLNeeded = (dosageNeeded * 5) / dosagePerMl
                mLNeeded
            }
            else -> 0.0
        }
        return dosage
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("dosage", dosage)
        outState.putDouble("weightInKgs", weightInKgs)
    }
}
